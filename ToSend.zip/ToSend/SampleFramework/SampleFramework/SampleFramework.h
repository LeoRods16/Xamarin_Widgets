//
//  SampleFramework.h
//  SampleFramework
//
//  Created by Leon Rodrigues on 08/03/22.
//

#import <Foundation/Foundation.h>

//! Project version number for SampleFramework.
FOUNDATION_EXPORT double SampleFrameworkVersionNumber;

//! Project version string for SampleFramework.
FOUNDATION_EXPORT const unsigned char SampleFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SampleFramework/PublicHeader.h>


