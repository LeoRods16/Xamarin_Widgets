﻿using System;
namespace NativeLibrary
{
    public class StructsAndEnums
    {
        public StructsAndEnums()
        {
        }
    }
}
