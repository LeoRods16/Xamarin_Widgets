//
//  WidgetTestAppApp.swift
//  WidgetTestApp
//
//  Created by Leon Rodrigues on 07/03/22.
//

import SwiftUI

@main
struct WidgetTestAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
