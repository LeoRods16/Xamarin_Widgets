//
//  ContentView.swift
//  WidgetTestApp
//
//  Created by Leon Rodrigues on 07/03/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, world!")
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
